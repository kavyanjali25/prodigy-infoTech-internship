# PRODIGY_ML_02

Prodigy Machine Learning Internship Task 2 - Create a K-means clustering algorithm to group customers of a retail store based on their purchase history.
